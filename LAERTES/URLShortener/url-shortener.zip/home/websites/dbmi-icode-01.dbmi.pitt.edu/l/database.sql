CREATE TABLE lil_urls (
  id varchar(1000) NOT NULL default '',
  url text,
  date timestamp NOT NULL,
  PRIMARY KEY  (id)
);
