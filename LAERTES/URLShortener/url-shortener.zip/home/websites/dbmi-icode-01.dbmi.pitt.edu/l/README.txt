HarryJerry Linx!

----------------------

This little script will let you run your own URL shortening service like TinyURL etc.
//Uses a GNU class with some modifications

License: GNU

Free to modify, redistribute.
----------------------

How to install?

1. Extract the contents of this compressed file into a folder and upload to your server.
2. Create a MySQL database and a user.
3. Open includes/conf.php and edit the database name and user/password as per step 2.
4. Import/Dump the contents of database.sql file using phpMyAdmin (if available). This is to create the database tables.
5. Buy me a chocolate brownie or this script won't work (just kidding).
6. Customize your site name in index.php and spice up the page.

------------------------

I need help!!!!


Support will be available online through web/e-mail. I can also install the script for you if you want me to. It's free of course! :)

Please feel free to mail me at harryjerry22@gmail.com

I'm on Twitter too: harry_jerry

I normally respond within 6 hours and maximum in 12 hours.


------------------------

www.harryjerry.com